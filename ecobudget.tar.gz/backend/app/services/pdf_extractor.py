class PDFExtractor:
    def extract_text(self, file_path: str):
        # TODO: Implémenter l'extraction avec pdfplumber
        pass

    def extract_tables(self, file_path: str):
        # TODO: Implémenter l'extraction de tableaux
        pass
